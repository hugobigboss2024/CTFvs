import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { getIronSession } from 'iron-session';
import { cookies } from 'next/headers';
import { SessionData, SESSION_OPTIONS } from './lib/session';

function setSecurityResponseHeader(response: NextResponse) {
  response.headers.set('X-Frame-Options', 'DENY');
  return response;
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const sessionCookie = request.cookies.get('session');

  const publicRoutes = ['/login', '/register'];
  const isPublicRoute = publicRoutes.some(route => pathname.startsWith(route));

  let isValidSession = false;
  if (sessionCookie) {
    try {
      const cookieStore = await cookies();
      const session = await getIronSession<SessionData>(cookieStore, SESSION_OPTIONS);
      
      isValidSession = !!(session.isLoggedIn && session.userId && session.username);
    } catch (error) {
      if (isPublicRoute) {
        const response = NextResponse.next();
        response.cookies.delete('session');
        return setSecurityResponseHeader(response);
      }
    }
  }

  if (!isValidSession && !isPublicRoute) {
    const response = NextResponse.redirect(new URL('/login', request.url));
    if (sessionCookie) {
      response.cookies.delete('session');
    }
    return setSecurityResponseHeader(response);
  }

  if (isValidSession && isPublicRoute) {
    const response = NextResponse.redirect(new URL('/', request.url));
    return setSecurityResponseHeader(response);
  }

  const response = NextResponse.next();
  return setSecurityResponseHeader(response);
}

export const config = {
  matcher: ['/', '/account/:path*', '/login', '/register'],
};
