#!/bin/sh
set -e

# Next.js Edge Runtime workaround for random session secret key and admin password
export SESSION_SECRET=$(od -An -N32 -tx1 /dev/urandom | tr -d ' \n')
export ADMIN_PASSWORD=$(od -An -N32 -tx1 /dev/urandom | tr -d ' \n')

node server.js