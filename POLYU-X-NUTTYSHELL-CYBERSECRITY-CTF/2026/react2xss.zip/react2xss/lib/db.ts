import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { FLAG, ADMIN_USERNAME, ADMIN_PASSWORD, DATABASE_PATH_NAME, DATABASE_FILENAME, DATABASE_CLEANUP_INTERVAL_MINUTE } from './config';

const dataDir = path.join(process.cwd(), DATABASE_PATH_NAME);
const dbPath = path.join(dataDir, DATABASE_FILENAME);

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const db = new Database(dbPath);

export function initializeDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      is_admin INTEGER DEFAULT 0,
      bio TEXT DEFAULT '',
      data TEXT DEFAULT '{}',
      profile_views INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  try {
    const adminExists = db.prepare('SELECT COUNT(*) as count FROM users WHERE username = ?').get(ADMIN_USERNAME) as { count: number };
    
    if (adminExists.count === 0) {
      db.prepare('INSERT INTO users (username, password, is_admin, bio, data) VALUES (?, ?, ?, ?, ?)').run(
        ADMIN_USERNAME,
        ADMIN_PASSWORD,
        1,
        FLAG,
        '{"website": "http://example.com", "location": "NuttyShell"}'
      );
      console.log('[+] Database initialized.');
      console.log(`[*] Admin credentials - Username: ${ADMIN_USERNAME}, Password: ${ADMIN_PASSWORD}`);
    }
  } catch (error) {
    // admin user already exists from another process, ignore
  }
}

function cleanupDatabase() {
  try {
    const row = db.prepare('SELECT COUNT(*) as count FROM users WHERE is_admin = 0').get() as { count: number } | undefined;
    const count = row?.count ?? 0;
    if (count === 0) {
      return;
    }

    db.prepare('DELETE FROM users WHERE is_admin = 0').run();
    console.log('[+] Database cleaned up.');
  } catch (error) {
    console.error('[-] Error during database cleanup:', error);
  }
}

export interface User {
  id: number;
  username: string;
  password: string;
  is_admin: number;
  bio: string;
  data: string;
  profile_views: number;
  created_at: string;
}

export const userDb = {
  create: (username: string, password: string): User | null => {
    try {
      const stmt = db.prepare('INSERT INTO users (username, password, is_admin) VALUES (?, ?, ?)');
      const result = stmt.run(username, password, 0);
      const user = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid) as User;
      return user;
    } catch (error) {
      return null;
    }
  },

  findByUsername: (username: string): User | null => {
    const stmt = db.prepare('SELECT * FROM users WHERE username = ?');
    return stmt.get(username) as User | null;
  },

  findById: (id: number): User | null => {
    const stmt = db.prepare('SELECT * FROM users WHERE id = ?');
    return stmt.get(id) as User | null;
  },

  updateData: (id: number, data: Record<string, any>): boolean => {
    try {
      const stmt = db.prepare('UPDATE users SET data = ? WHERE id = ?');
      stmt.run(JSON.stringify(data), id);
      return true;
    } catch (error) {
      return false;
    }
  },

  updateBioAndData: (id: number, bio: string, data: Record<string, any>): boolean => {
    try {
      const stmt = db.prepare('UPDATE users SET bio = ?, data = ? WHERE id = ?');
      stmt.run(bio, JSON.stringify(data), id);
      return true;
    } catch (error) {
      return false;
    }
  },

  incrementProfileViews: (id: number): number => {
    try {
      const stmt = db.prepare('UPDATE users SET profile_views = profile_views + 1 WHERE id = ?');
      stmt.run(id);
      const user = db.prepare('SELECT profile_views FROM users WHERE id = ?').get(id) as { profile_views: number };
      return user.profile_views;
    } catch (error) {
      return 0;
    }
  },

  verifyPassword: (password: string, storedPassword: string): boolean => {
    return password === storedPassword;
  }
};

initializeDatabase();
setInterval(cleanupDatabase, DATABASE_CLEANUP_INTERVAL_MINUTE);

export default db;
