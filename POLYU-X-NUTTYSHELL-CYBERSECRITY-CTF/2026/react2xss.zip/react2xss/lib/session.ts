import { getIronSession, IronSession } from 'iron-session';
import { cookies } from 'next/headers';
import { SESSION_SECRET } from './config';

export interface SessionData {
  userId?: number;
  username?: string;
  isLoggedIn: boolean;
  csrfToken?: string;
}

export const SESSION_OPTIONS = {
  password: SESSION_SECRET,
  cookieName: 'session',
  cookieOptions: {
    secure: false,
    httpOnly: true,
    maxAge: 60 * 60 * 24,
    sameSite: 'Lax'
  },
};

export async function getSession(): Promise<IronSession<SessionData>> {
  const cookieStore = await cookies();
  return getIronSession<SessionData>(cookieStore, SESSION_OPTIONS);
}

export async function createSession(userId: number, username: string) {
  const session = await getSession();
  session.userId = userId;
  session.username = username;
  session.isLoggedIn = true;
  await session.save();
}

export async function destroySession() {
  const session = await getSession();
  session.destroy();
}

export async function getCurrentUser(): Promise<{ userId: number; username: string } | null> {
  try {
    const session = await getSession();
    if (session.isLoggedIn && session.userId && session.username) {
      return { userId: session.userId, username: session.username };
    }
    return null;
  } catch (error) {
    return null;
  }
}
