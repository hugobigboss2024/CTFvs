export const FLAG = process.env.FLAG || 'PUCTF26{fake_flag}';
export const SESSION_SECRET = process.env.SESSION_SECRET || 'session-secret-key-will-be-different-and-random-in-the-remote-instance';
export const ADMIN_USERNAME = 'admin';
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || crypto.randomUUID();
export const PASSWORD_MIN_LENGTH = 10;
export const PASSWORD_MAX_LENGTH = 72;
export const DATABASE_PATH_NAME = 'data';
export const DATABASE_FILENAME = 'app.db';
export const DATABASE_CLEANUP_INTERVAL_MINUTE = 30 * 60 * 1000;

export const BOT_CONFIG = {
  APPURL: process.env.APPURL || 'http://localhost:3000',
  APPLIMITTIME: Number(process.env.APPLIMITTIME || '60000'),
  APPLIMIT: Number(process.env.APPLIMIT || '2'),
  VISIT_TIMEOUT: 10000,
  WAIT_AFTER_LOGIN: 1000,
  WAIT_AFTER_VISIT: 5000,
};

export const RATE_LIMITING_ENABLED = process.env.ENABLE_RATE_LIMITING === 'True';
export const TURNSTILE_CONFIG = {
  ENABLED: process.env.ENABLE_TURNSTILE === 'True',
  SITE_KEY: process.env.TURNSTILE_SITE_KEY || '',
  SECRET_KEY: process.env.TURNSTILE_SECRET_KEY || '',
};

if (TURNSTILE_CONFIG.ENABLED) {
  if (TURNSTILE_CONFIG.SITE_KEY === '' || TURNSTILE_CONFIG.SECRET_KEY === '') {
    throw new Error('Turnstile is enabled, but SITE_KEY or SECRET_KEY is missing.');
  }
}