import { chromium } from 'playwright';
import { ADMIN_USERNAME, BOT_CONFIG } from './config';
import { userDb } from './db';

const browserArgs = {
  headless: true,
  args: [
    '--disable-dev-shm-usage',
    '--disable-gpu',
    '--no-gpu',
    '--disable-default-apps',
    '--disable-translate',
    '--disable-device-discovery-notifications',
    '--disable-software-rasterizer',
    '--disable-xss-auditor',
    '--disable-crash-reporter'
  ],
  env: {
    ...process.env,
    HOME: '/tmp'
  }
};

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function visitUrl(urlToVisit: string): Promise<boolean> {
  const adminUser = userDb.findByUsername(ADMIN_USERNAME);
  if (!adminUser || adminUser.is_admin !== 1) {
    console.error('Admin user does not exist or is not an admin.');
    return false;
  }

  const browser = await chromium.launch(browserArgs);
  const context = await browser.newContext();

  try {
    const page = await context.newPage();
    page.setDefaultTimeout(BOT_CONFIG.VISIT_TIMEOUT);
    
    console.log('[*] Bot logging in as admin...');
    await page.goto(`${BOT_CONFIG.APPURL}/login`, { waitUntil: 'load' });
    
    await page.fill('input[id="username"]', ADMIN_USERNAME);
    await page.fill('input[id="password"]', adminUser.password); // using database password instead of the config one, cuz it might be changed during build time
    await page.click('button[type="submit"]');
    await sleep(BOT_CONFIG.WAIT_AFTER_LOGIN);
    console.log('[*] Bot logged in successfully');
  
    console.log(`[*] Bot visiting ${urlToVisit}`);
    await page.goto(urlToVisit, { waitUntil: 'load' });
    await sleep(BOT_CONFIG.WAIT_AFTER_VISIT);
    
    console.log('[*] Bot finished visiting');
    return true;
  } catch (e) {
    console.error('[-] Bot error:', e);
    return false;
  } finally {
    await context.close();
    await browser.close();
    console.log('[*] Bot browser closed');
  }
}
