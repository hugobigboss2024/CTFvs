import crypto from 'crypto';

export function generateCSRFToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

export function validateCSRFToken(token: string | null | undefined, sessionToken: string | undefined): boolean {
  if (!token || !sessionToken) {
    return false;
  }
  return token === sessionToken;
}
