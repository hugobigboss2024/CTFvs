'use server';

import { getSession } from '@/lib/session';
import { generateCSRFToken } from '@/lib/csrf';

export async function getCSRFToken(): Promise<string | null> {
  try {
    const session = await getSession();
    
    if (!session.isLoggedIn) {
      return null;
    }

    if (!session.csrfToken) {
      session.csrfToken = generateCSRFToken();
      await session.save();
    }

    return session.csrfToken;
  } catch (error) {
    return null;
  }
}
