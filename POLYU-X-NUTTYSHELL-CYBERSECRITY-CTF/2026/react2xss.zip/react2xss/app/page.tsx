import { getCurrentUser } from '@/lib/session';
import { userDb } from '@/lib/db';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { logout } from './actions';

export default async function Home() {
  const currentUser = await getCurrentUser();
  if (!currentUser) {
    redirect('/login');
  }

  const user = userDb.findById(currentUser.userId);
  if (!user) {
    redirect('/api/auth/clear');
  }

  let userData: Record<string, any> = {};
  try {
    userData = JSON.parse(user.data || '{}');
  } catch (e) {
    userData = {};
  }

  const viewCount = userDb.incrementProfileViews(currentUser.userId);

  return (
    <>
      <nav className="nav">
        <div className="nav-content">
          <div>
            <strong>Welcome, {user.username}</strong>
          </div>
          <div>
            <Link href="/account/settings">Settings</Link>
            <Link href="/report" style={{ marginLeft: '1rem' }}>Report</Link>
            <form action={logout} style={{ display: 'inline', marginLeft: '1rem' }}>
              <button type="submit" style={{ background: 'transparent', color: '#0070f3', padding: 0 }}>
                Logout
              </button>
            </form>
          </div>
        </div>
      </nav>
      
      <div className="container">
        <div className="card">
          <h1>Your Profile</h1>
          
          <div className="profile-info">
            <p><strong>Username:</strong> {user.username}</p>
            <p><strong>Bio:</strong> {user.bio || 'No bio set'}</p>
            
            {userData.website && (
              <p>
                <strong>Website:</strong>{' '}
                <Link href={userData.website} className="link">{userData.website}</Link>
              </p>
            )}
            
            {userData.location && (
              <p><strong>Location:</strong> {userData.location}</p>
            )}

            <strong>Current Profile Views Progress (Free flags if you reach 100% 🗣️) :</strong>{' '}
            {viewCount >= 100 && (
              <span>🎉 Congratulations! You've unlocked a <Link href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" className="link">free flag</Link>! 🎉</span>
            )}
            <progress max={100} value={viewCount} {...userData.viewProgressStyle} />
          </div>

          <Link href="/account/settings" className="link">Edit Profile</Link>
        </div>
      </div>
    </>
  );
}
