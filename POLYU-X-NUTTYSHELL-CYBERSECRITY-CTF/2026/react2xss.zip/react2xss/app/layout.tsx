import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Profile Viewer',
  description: 'Profile Viewer Application',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
