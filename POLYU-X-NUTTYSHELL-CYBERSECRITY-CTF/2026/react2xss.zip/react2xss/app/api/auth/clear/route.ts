import { destroySession } from '@/lib/session';
import { NextResponse } from 'next/server';

export async function GET(request: Request) {
  await destroySession();
  const host = request.headers.get('host') || 'localhost:3000';
  return NextResponse.redirect(new URL('/login', `http://${host}`));
}
