import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/session';
import { userDb } from '@/lib/db';
import { validateCSRFToken, generateCSRFToken } from '@/lib/csrf';

export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session.isLoggedIn || !session.userId) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const csrfToken = request.headers.get('x-csrf-token');
    if (!validateCSRFToken(csrfToken, session.csrfToken)) {
      return NextResponse.json(
        { error: 'Invalid CSRF token' },
        { status: 403 }
      );
    }

    const newCsrfToken = generateCSRFToken();
    session.csrfToken = newCsrfToken;
    await session.save();

    const user = userDb.findById(session.userId);
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    if (user.is_admin === 1) {
      return NextResponse.json(
        { error: 'Admins cannot update their profile' },
        { status: 403 }
      );
    }

    const { bio, ...dynamicFields } = await request.json();

    let userData: Record<string, any> = {};
    try {
      userData = JSON.parse(user.data || '{}');
    } catch (e) {
      userData = {};
    }

    const updatedData = {
      ...userData,
      ...dynamicFields
    };

    if (bio !== undefined) {
      userDb.updateBioAndData(session.userId, bio, updatedData);
    } else {
      const success = userDb.updateData(session.userId, updatedData);
      if (!success) {
        return NextResponse.json(
          { error: 'Failed to update profile data' },
          { status: 500 }
        );
      }
    }

    return NextResponse.json(
      { message: 'Profile updated successfully', newCsrfToken },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
