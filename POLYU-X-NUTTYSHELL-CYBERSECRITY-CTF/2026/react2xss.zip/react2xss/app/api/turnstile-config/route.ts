// CloudFlare Turnstile, not related to the challenge
import { NextResponse } from 'next/server';
import { TURNSTILE_CONFIG } from '@/lib/config';

export async function GET() {
  return NextResponse.json({
    enabled: TURNSTILE_CONFIG.ENABLED,
    siteKey: TURNSTILE_CONFIG.SITE_KEY,
  });
}
