import { NextRequest, NextResponse } from 'next/server';
import { visitUrl } from '@/lib/bot';
import { checkRateLimit } from '@/lib/ratelimit';
import { BOT_CONFIG, TURNSTILE_CONFIG, RATE_LIMITING_ENABLED } from '@/lib/config';

// CloudFlare Turnstile, not related to the challenge
async function verifyTurnstile(token: string, ip: string): Promise<boolean> {
  if (!TURNSTILE_CONFIG.ENABLED || !TURNSTILE_CONFIG.SECRET_KEY) {
    return true;
  }
  if (!token || typeof token !== 'string') {
    console.error('Turnstile verification error: Invalid token');
    return false;
  }

  try {
    const response = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        secret: TURNSTILE_CONFIG.SECRET_KEY,
        response: token,
        remoteip: ip,
      }),
    });

    const data = await response.json();
    return data.success === true;
  } catch (error) {
    console.error('Turnstile verification error:', error);
    return false;
  }
}

export async function POST(request: NextRequest) {
  try {
    const ip = request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown';
    
    if (RATE_LIMITING_ENABLED === true) {
      const rateLimit = checkRateLimit(ip, BOT_CONFIG.APPLIMITTIME, BOT_CONFIG.APPLIMIT);
      if (!rateLimit.allowed) {
        return NextResponse.json(
          { error: 'Rate limit exceeded. Please try again later.' },
          { status: 429 }
        );
      }
    }

    const { url, token } = await request.json();

    if (!url || typeof url !== 'string') {
      return NextResponse.json(
        { error: 'URL is required' },
        { status: 400 }
      );
    }

    const isValidToken = await verifyTurnstile(token, ip);
    if (!isValidToken) {
      return NextResponse.json(
        { error: 'Invalid CAPTCHA. Please try again.' },
        { status: 400 }
      );
    }

    const parsedUrl = new URL(url);
    if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') {
      return NextResponse.json(
        { error: 'Invalid URL protocol' },
        { status: 400 }
      );
    }

    visitUrl(parsedUrl.toString()).catch(err => console.error('Bot error:', err));

    return NextResponse.json(
      { success: 'URL submitted successfully. The admin will visit it shortly.' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Report error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
