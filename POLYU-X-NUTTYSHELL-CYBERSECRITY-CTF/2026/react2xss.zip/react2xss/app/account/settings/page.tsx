'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { getCSRFToken } from '@/app/actions/csrf';

export default function Settings() {
  const [bio, setBio] = useState('');
  const [website, setWebsite] = useState('');
  const [location, setLocation] = useState('');
  const [viewProgressStyleJson, setViewProgressStyleJson] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [csrfToken, setCsrfToken] = useState('');
  const router = useRouter();

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await fetch('/api/profile');
        if (!res.ok) {
          router.push('/login');
          return;
        }
        const data = await res.json();
        setBio(data.bio || '');
        setWebsite(data.website || '');
        setLocation(data.location || '');
        
        if (data.viewProgressStyle?.style) {
          setViewProgressStyleJson(JSON.stringify(data.viewProgressStyle.style, null, 2));
        }
      } catch (err) {
        setError('Failed to load profile');
      } finally {
        setInitialLoading(false);
      }
    };

    const fetchCSRFToken = async () => {
      try {
        const token = await getCSRFToken();
        if (token) {
          setCsrfToken(token);
        }
      } catch (err) {
        console.error('Failed to fetch CSRF token:', err);
      }
    };

    fetchProfile();
    fetchCSRFToken();
  }, [router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      let viewProgressStyle = undefined;
      if (viewProgressStyleJson.trim()) {
        try {
          const parsedStyle = JSON.parse(viewProgressStyleJson);
          viewProgressStyle = { style: parsedStyle };
        } catch (err) {
          setError('Invalid JSON in progress bar style field');
          setLoading(false);
          return;
        }
      }

      const res = await fetch('/api/profile/update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken,
        },
        body: JSON.stringify({ bio, website, location, viewProgressStyle }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Update failed');
        setLoading(false);
        return;
      }

      if (data.newCsrfToken) {
        setCsrfToken(data.newCsrfToken);
      }

      setSuccess('Profile updated successfully');
      setLoading(false);
      
      setTimeout(() => {
        router.refresh();
      }, 1000);
    } catch (err) {
      setError('An error occurred');
      setLoading(false);
    }
  };

  if (initialLoading) {
    return (
      <div className="container">
        <div className="card">
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <nav className="nav">
        <div className="nav-content">
          <div>
            <strong>Settings</strong>
          </div>
          <div>
            <Link href="/">Profile</Link>
          </div>
        </div>
      </nav>
      
      <div className="container">
        <div className="card">
          <h1>Profile Settings</h1>
          
          {error && <div className="error">{error}</div>}
          {success && <div className="success">{success}</div>}
          
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="bio">Bio</label>
              <textarea
                id="bio"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                maxLength={500}
              />
            </div>

            <div className="form-group">
              <label htmlFor="viewProgressStyleJson">Progress Bar Custom Style (JSON)</label>
              <textarea
                id="viewProgressStyleJson"
                value={viewProgressStyleJson}
                onChange={(e) => setViewProgressStyleJson(e.target.value)}
                placeholder='{"accentColor": "#00ff00", "height": "20px"}'
                rows={4}
              />
              <small style={{ color: '#666', fontSize: '0.875rem' }}>
                Enter CSS properties as JSON to customize your profile views progress bar!
              </small>
            </div>

            <div className="form-group">
              <label htmlFor="website">Website</label>
              <input
                id="website"
                type="url"
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                placeholder="http://example.com"
              />
            </div>

            <div className="form-group">
              <label htmlFor="location">Location</label>
              <input
                id="location"
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="City, Country"
              />
            </div>

            <button type="submit" disabled={loading} style={{ width: '100%', marginTop: '1rem' }}>
              {loading ? 'Updating...' : 'Update Profile'}
            </button>
          </form>
        </div>
      </div>
    </>
  );
}
