'use client';

import { useState, FormEvent, useEffect } from 'react';
import Link from 'next/link';
import Script from 'next/script';

export default function Report() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [turnstileToken, setTurnstileToken] = useState('');
  const [turnstileLoaded, setTurnstileLoaded] = useState(false);
  const [turnstileEnabled, setTurnstileEnabled] = useState(false);
  const [turnstileSiteKey, setTurnstileSiteKey] = useState('');

  useEffect(() => {
    fetch('/api/turnstile-config')
      .then(res => res.json())
      .then(data => {
        setTurnstileEnabled(data.enabled);
        setTurnstileSiteKey(data.siteKey);
      })
      .catch(err => console.error('Failed to fetch Turnstile config:', err));
  }, []);

  useEffect(() => {
    if (turnstileEnabled && turnstileLoaded && turnstileSiteKey && (window as any).turnstile) {
      (window as any).turnstile.render('#cf-turnstile', {
        sitekey: turnstileSiteKey,
        callback: (token: string) => {
          setTurnstileToken(token);
        }
      });
    }
  }, [turnstileEnabled, turnstileLoaded, turnstileSiteKey]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      const res = await fetch('/api/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url, token: turnstileToken }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Failed to submit URL');
        setLoading(false);
        if ((window as any).turnstile) {
          (window as any).turnstile.reset('#cf-turnstile');
        }
        return;
      }

      setSuccess(data.success);
      setUrl('');
      setLoading(false);
      if (turnstileEnabled && (window as any).turnstile) {
        (window as any).turnstile.reset('#cf-turnstile');
      }
    } catch (err) {
      setError('An error occurred while submitting the URL');
      setLoading(false);
      if (turnstileEnabled && (window as any).turnstile) {
        (window as any).turnstile.reset('#cf-turnstile');
      }
    }
  };

  return (
    <>
      {turnstileEnabled && (
        <Script
          src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit"
          onLoad={() => setTurnstileLoaded(true)}
        />
      )}
      <div className="container">
        <div className="card" style={{ maxWidth: '600px', margin: '4rem auto' }}>
          <h1>Report to Admin</h1>
          
          {error && <div className="error">{error}</div>}
          {success && <div className="success">{success}</div>}
          
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="url">Enter the URL for admin to visit:</label>
              <input
                id="url"
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                required
                placeholder="http://example.com/foo"
              />
            </div>

            {turnstileEnabled && (
              <div className="form-group">
                <div id="cf-turnstile"></div>
              </div>
            )}

            <button type="submit" disabled={loading} style={{ width: '100%' }}>
              {loading ? 'Submitting...' : 'Submit URL'}
            </button>
          </form>

          <p className="text-center mt-1">
            <Link href="/" className="link">Back to Home</Link>
          </p>
        </div>
      </div>
    </>
  );
}
