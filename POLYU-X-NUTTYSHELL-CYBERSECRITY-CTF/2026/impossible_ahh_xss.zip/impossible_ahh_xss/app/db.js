const sqlite3 = require('sqlite3');
const { open } = require('sqlite');

const CREATE_TABLE_SQL = `
CREATE TABLE IF NOT EXISTS sites (
    id TEXT PRIMARY KEY UNIQUE NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL
)
`;

async function init() {
    const db = await open({
        filename: ':memory:',
        driver: sqlite3.Database
    });

    await db.exec(CREATE_TABLE_SQL);
    return db;
}

async function cleanup(db) {
    console.log('[*] Cleaning up database...');
    await db.exec('DROP TABLE IF EXISTS sites');
    await db.exec(CREATE_TABLE_SQL);
    console.log('[*] Database cleaned');
}

module.exports = { init, cleanup };
