const { chromium } = require('playwright');

const FLAG = process.env['FLAG'] || "PUCTF26{fake_flag}";
const CONFIG = {
    APPNAME: process.env['APPNAME'] || "Admin",
    APPURL: process.env['APPURL'] || "http://localhost:3000",
    APPDOMAIN: process.env['APPDOMAIN'] || "localhost",
    APPURLREGEX: process.env['APPURLREGEX'] || "^.*$",
    APPLIMITTIME: Number(process.env['APPLIMITTIME'] || "60000"),
    APPLIMIT: Number(process.env['APPLIMIT'] || "5"),
};
const BROWSER_ARGS = {
    headless: true,
    args: [
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--no-gpu',
        '--disable-default-apps',
        '--disable-translate',
        '--disable-device-discovery-notifications',
        '--disable-software-rasterizer',
        '--disable-xss-auditor',
        '--disable-crash-reporter'
    ],
    ignoreHTTPSErrors: true
};

console.table(CONFIG);
console.log("Bot started...");

function sleepSeconds(sec) {
    return new Promise((resolve) => setTimeout(resolve, sec * 1000));
}

module.exports = {
    name: CONFIG.APPNAME,
    urlRegex: CONFIG.APPURLREGEX,
    rateLimit: {
        windowMs: CONFIG.APPLIMITTIME,
        limit: CONFIG.APPLIMIT
    },
    bot: async (urlToVisit) => {
        const browser = await chromium.launch(BROWSER_ARGS);
        const context = await browser.newContext();

        try {
            const page = await context.newPage();
            page.setDefaultTimeout(15_000);

            console.log(`[*] Bot adding flag cookie for domain ${CONFIG.APPDOMAIN}...`);
            await context.addCookies([{
                'name': 'flag',
                'value': FLAG,
                'domain': CONFIG['APPDOMAIN'],
                'path': '/',
                'httpOnly': false,
                'sameSite': 'Strict',
            }]);

            console.log(`[*] Bot visiting ${urlToVisit} ...`);
            await page.goto(urlToVisit, { waitUntil: 'load', timeout: 10_000 });
            await sleepSeconds(10);

            console.log('[*] Bot finished visiting');
            return true;
        } catch (e) {
            console.error('[-] Bot error:', e);
            return false;
        } finally {
            await context.close();
            await browser.close();
            console.log('[*] Bot browser closed');
        }
    }
};