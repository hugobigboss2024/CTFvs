const express = require('express');
const path = require('path');
const crypto = require('crypto');
const { init, cleanup } = require('./db');
const bot = require('./bot');
const rateLimit = require('express-rate-limit');

const DATABASE_CLEANUP_INTERVAL_MINUTE = 60 * 30 * 1000;
const IS_TURNSTILE_ENABLED = (process.env['ENABLE_TURNSTILE']?.toLowerCase() === 'true') || false;
const TURNSTILE_SITE_KEY = process.env['TURNSTILE_SITE_KEY'] || '';
const TURNSTILE_SECRET = process.env['TURNSTILE_SECRET'] || '';

const limit = rateLimit({
    ...bot.rateLimit,
    handler: ((req, res, _next) => {
        const timeRemaining = Math.ceil((req.rateLimit.resetTime - Date.now()) / 1000)
        res.status(429).json({
            error: `Too many requests, please try again later after ${timeRemaining} seconds.`,
        });
    })
})
const app = express();

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: false }));
app.use('/static', express.static(path.join(__dirname, 'public')));

app.use((req, res, next) => {
    if (req.path === '/report') {
        return next();
    }

    res.set({
        'X-Frame-Options': 'DENY',
        'X-Content-Type-Options': 'nosniff',
        'Content-Security-Policy': "default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline'; connect-src 'self' https://cdn.jsdelivr.net; img-src 'self'; font-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-src 'self';"
    });
    next();
});

// Cloudflare Turnstile Captcha
// NOT related to the challenge.
async function verifyCaptcha(answer, ip) {
    const formData = new FormData();
    formData.append('secret', TURNSTILE_SECRET);
    formData.append('response', answer);
    formData.append('remoteip', ip);

    try {
        const response = await fetch(
            'https://challenges.cloudflare.com/turnstile/v0/siteverify', {
                method: 'POST',
                body: formData
            }
        );
        const json = await response.json();
        if (!json.success) {
            return false;
        }

        return true;
    } catch (error) {
        return false;
    }
}

const generateRandomSiteId = () => crypto.randomBytes(32).toString('hex');

init().then(db => {
    app.get('/', async (req, res) => {
        return res.render('index');
    });

    app.post('/sites', async (req, res) => {
        const title = (req.body.title || '').trim();
        const content = req.body.content || '';

        if (!title || !content) {
            return res.status(400).send('Title and content are required');
        }
        if (typeof title !== 'string' || typeof content !== 'string') {
            return res.status(400).send('Invalid title or content');
        }
        if (title.length > 255 || content.length > 10000) {
            return res.status(400).send('Title or content too long');
        }

        const id = generateRandomSiteId();
        try {
            await db.run('INSERT INTO sites (id, title, content) VALUES (?, ?, ?)', [id, title, content]);
        } catch (err) {
            console.error('Failed to create site:', err);
            return res.status(500).send('Failed to create site');
        }

        return res.redirect(`/sites/${encodeURIComponent(id)}`);
    });

    app.get('/sites/:id', async (req, res) => {
        const id = req.params.id;
        if (!id || typeof id !== 'string') {
            return res.status(400).send('Invalid ID');
        }

        const site = await db.get('SELECT id, title FROM sites WHERE id = ?', [id]);
        if (!site) return res.status(404).render('404');

        return res.render('site', { site });
    });

    app.get('/api/sites/:id/content', async (req, res) => {
        if (req.headers['x-requested-with'] !== 'XMLHttpRequest') {
            return res.status(400).send(JSON.stringify({ error: 'All API calls must be made via XMLHttpRequest' }));
        }

        const id = req.params.id;
        if (!id || typeof id !== 'string') {
            return res.status(400).send(JSON.stringify({ error: 'Invalid site ID' }));
        }

        const row = await db.get('SELECT content FROM sites WHERE id = ?', [id]);
        if (!row) return res.status(404).send(JSON.stringify({ error: 'Site not found' }));

        return res.send(JSON.stringify({ content: row.content }));
    });

    app.get('/report', async (req, res) => {
        const { name } = bot
        return res.render('report', {
            name,
            isTurnstileEnabled: IS_TURNSTILE_ENABLED,
            turnstileSiteKey: TURNSTILE_SITE_KEY
        });
    });

    app.post('/report', limit, async (req, res) => {
        // Cloudflare Turnstile Captcha validation
        // NOT related to the challenge.
        if (IS_TURNSTILE_ENABLED) {
            if (TURNSTILE_SECRET === '') {
                return res.status(500).send({ error: 'This server did not have the Cloudflare Turnstile secret key.' });
            }

            const ip = req.headers['cf-connecting-ip'] || req.socket.remoteAddress;
            const { answer } = req.body;
            if (!answer) {
                return res.status(400).send({ error: 'Please complete the Cloudflare Turnstile Captcha.' });
            }

            isVerified = await verifyCaptcha(answer, ip);
            if (!isVerified) {
                return res.status(422).json({ error: 'Invalid Cloudflare Turnstile token.' });
            }
        }

        const url = (req.body.url || '').trim();
        if (!url || typeof url !== 'string') {
            return res.status(400).send('Invalid URL');
        }
        
        let parsedUrl;
        try {
            parsedUrl = new URL(url);
        } catch (e) {
            return res.status(400).send('Invalid URL');
        }

        if (!RegExp(bot.urlRegex).test(parsedUrl.href)) {
            return res.status(422).send({ error: `URL didn't match this regex format ${bot.urlRegex}` })
        }
        if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') {
            return res.status(422).send({ error: 'Only http and https protocols are allowed' });
        }
        if (await bot.bot(parsedUrl.href)) {
            return res.send({ success: 'Admin successfully visited the URL.' });
        } else {
            return res.status(500).send({ error: 'Admin failed to visit the URL.' });
        }
    });

    app.listen(3000, '0.0.0.0', () => {
        console.log(`Server listening on port 3000`);
    });

    setInterval(() => {
        cleanup(db).catch(err => {
            console.error('Failed to clean up database:', err);
        });
    }, DATABASE_CLEANUP_INTERVAL_MINUTE);
}).catch(err => {
    console.error('Failed to start:', err);
    process.exit(1);
});