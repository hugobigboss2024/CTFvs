const isHexadecimal = str => /^[0-9A-Fa-f]+$/.test(str);
const DOMPURIFY_CONFIG = {
    ALLOWED_TAGS: ['b', 'i', 'em', 'strong', 'p', 'br', 'ul', 'ol', 'li', 'span', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'],
    ALLOWED_ATTR: ['class', 'style']
};

const siteId = new URL(window.location.href).pathname.split('/').pop();
if (!siteId || typeof siteId !== 'string' || !isHexadecimal(siteId)) {
    $('#siteFrame').attr('srcdoc', '<p>Invalid site ID.</p>');
}

$.getJSON(`/api/sites/${encodeURIComponent(siteId)}/content`, function (data) {
    $('#siteFrame').attr('srcdoc', DOMPurify.sanitize(data.content, DOMPURIFY_CONFIG));
}).fail(function () {
    $('#siteFrame').attr('srcdoc', '<p>Failed to load site frame.</p>');
});