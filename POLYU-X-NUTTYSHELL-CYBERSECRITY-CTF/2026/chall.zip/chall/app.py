import os
import re
from flask import Flask, request, jsonify, render_template
from cloud_cli import COMMANDS
from cloud_cli.state import _maint_check

app = Flask(__name__)

FLAG = os.environ.get("FLAG", "")


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/cli", methods=["POST"])
def cli():
    data = request.get_json(silent=True)
    if not data or "args" not in data:
        return jsonify({"error": "missing 'args'"}), 400
    args = data["args"]
    if not isinstance(args, list) or not all(isinstance(a, str) for a in args):
        return jsonify({"error": "'args' must be a list of strings"}), 400
    if len(args) < 2:
        return jsonify({"error": "usage: {group} {command} [options]"}), 400

    handler = COMMANDS.get((args[0], args[1]))
    if not handler:
        return jsonify({"error": f"unknown command: {args[0]} {args[1]}"}), 404

    try:
        return jsonify(handler(args[2:]))
    except PermissionError as e:
        return jsonify({"error": str(e)}), 403
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/internal/maint")
def internal_maint():
    if request.remote_addr not in ("127.0.0.1",):
        return jsonify({"error": "forbidden"}), 403
    return jsonify({"token": _maint_check.__closure__[0].cell_contents["token"]})


@app.route("/api/logs/<session_id>")
def webapp_logs(session_id):
    if not re.fullmatch(r"[0-9a-f\-]{36}", session_id):
        return jsonify({"error": "invalid session"}), 400
    path = f"/tmp/cloud_cli_{session_id}.log"
    try:
        with open(path) as f:
            content = f.read().strip()
        os.unlink(path)
        return jsonify({"content": content})
    except FileNotFoundError:
        return jsonify({"content": ""})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
