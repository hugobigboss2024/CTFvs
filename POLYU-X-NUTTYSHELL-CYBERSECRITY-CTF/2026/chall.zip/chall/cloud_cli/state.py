import os
import secrets


def _make_check():
    state = {"token": secrets.token_hex(8)}
    def _inner(given):
        return bool(state["token"]) and given == state["token"]
    return _inner


_maint_check = _make_check()

os._cloud_exec = ["echo", "restarted"]
