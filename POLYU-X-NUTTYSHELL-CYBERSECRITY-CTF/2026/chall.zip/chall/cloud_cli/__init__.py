from cloud_cli.commands import COMMANDS

__all__ = ["COMMANDS"]
