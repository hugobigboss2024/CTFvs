import re
import json

_BRACKET = re.compile(r"^\[(\d+)\]$")


def _snake(s):
    s = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", s)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s).lower()


def _resolve(obj, parts):
    for p in parts:
        m = _BRACKET.match(p)
        if m:
            obj = obj[int(m.group(1))]
        elif isinstance(obj, dict):
            obj = obj[p]
        else:
            if p.startswith("__") and p.endswith("__"):
                raise ValueError(f"restricted: {p}")
            obj = getattr(obj, _snake(p))
    return obj


def _apply(obj, expr):
    if "=" not in expr:
        raise ValueError("invalid expression, expected KEY=VALUE")
    key, raw = expr.split("=", 1)
    key = key.strip()
    try:
        value = json.loads(raw)
    except Exception:
        value = raw
    parts  = key.split(".")
    target = _resolve(obj, parts[:-1]) if len(parts) > 1 else obj
    attr   = parts[-1]
    if isinstance(target, dict):
        target[attr] = value
    else:
        s = _snake(attr)
        if s.startswith("__") and s.endswith("__"):
            raise ValueError(f"restricted: {attr}")
        setattr(target, s, value)
