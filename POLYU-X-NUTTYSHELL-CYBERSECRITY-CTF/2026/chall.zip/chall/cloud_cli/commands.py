import os
import re
import uuid
import secrets
import threading
import subprocess
import urllib.request
import urllib.error
from string import Template
from urllib.parse import urlparse

from cloud_cli.traversal import _apply
from cloud_cli.state import _maint_check

_URL_DENYLIST = re.compile(
    r"(^|\.)localhost$"
    r"|^127\."
    r"|^10\."
    r"|^192\.168\."
    r"|^172\.(1[6-9]|2[0-9]|3[01])\."
    r"|^0\.0\.0\.0$"
    r"|^::1$",
    re.IGNORECASE,
)


class Resource:
    def __init__(self, rid):
        self.id         = rid
        self.name       = rid.split("/")[-1] if "/" in rid else rid
        self.location   = "eastus"
        self.kind       = "app"
        self.tags       = {}
        self.properties = {"state": "Running"}

    def to_dict(self):
        return {
            "id":         self.id,
            "name":       self.name,
            "location":   self.location,
            "kind":       self.kind,
            "tags":       self.tags,
            "properties": self.properties,
        }


class WebApp(Resource):
    def __init__(self, rid):
        super().__init__(rid)
        self.kind = "webapp"
        self.sku  = "Free"
        self.properties = {
            "state":           "Running",
            "defaultHostName": f"{self.name}.azurewebsites.net",
        }


def _opt(args, flag, required=True):
    try:
        return args[args.index(flag) + 1]
    except (ValueError, IndexError):
        if required:
            raise ValueError(f"missing required option: {flag}")
        return None


def _resource_update(args):
    res = Resource(_opt(args, "--ids"))
    _apply(res, _opt(args, "--set"))
    return res.to_dict()


def _resource_show(args):
    return Resource(_opt(args, "--ids")).to_dict()


def _resource_describe(args):
    rid      = _opt(args, "--ids")
    template = _opt(args, "--template", required=False) or "$name @ $location ($kind)"
    res      = Resource(rid)
    fields   = {k: str(v) for k, v in res.to_dict().items() if isinstance(v, str)}
    try:
        return {"output": Template(template).substitute(fields)}
    except (KeyError, ValueError) as e:
        raise ValueError(f"invalid template: {e}")


def _webapp_update(args):
    webapp = WebApp(_opt(args, "--ids"))
    _apply(webapp, _opt(args, "--set"))
    return webapp.to_dict()


def _webapp_show(args):
    return WebApp(_opt(args, "--ids")).to_dict()


def _webapp_notify(args):
    _opt(args, "--ids")
    webhook = _opt(args, "--webhook")
    parsed  = urlparse(webhook)
    if parsed.scheme not in ("http", "https"):
        raise ValueError("scheme must be http or https")
    host = parsed.hostname or ""
    if _URL_DENYLIST.search(host):
        raise ValueError("webhook host is not allowed")
    try:
        with urllib.request.urlopen(webhook, timeout=5) as r:
            return {"status": r.status, "body": r.read(512).decode(errors="replace")}
    except urllib.error.URLError as e:
        raise ValueError(str(e))


def _webapp_restart(args):
    rid      = _opt(args, "--ids")
    token    = _opt(args, "--token")
    if not _maint_check(token):
        raise PermissionError("maintenance mode is not active")
    session  = str(uuid.uuid4())
    log_path = f"/tmp/cloud_cli_{session}.log"
    env      = {**os.environ, "CLOUD_SESSION_LOG": log_path}
    try:
        subprocess.run(
            os._cloud_exec,
            capture_output=True,
            text=True,
            timeout=5,
            env=env,
        )
        threading.Timer(
            3.0,
            lambda: os.unlink(log_path) if os.path.exists(log_path) else None,
        ).start()
        return {"status": "restarted", "resource": rid, "session": session}
    finally:
        _maint_check.__closure__[0].cell_contents["token"] = secrets.token_hex(8)
        os._cloud_exec = ["echo", "restarted"]


COMMANDS = {
    ("resource", "update"):   _resource_update,
    ("resource", "show"):     _resource_show,
    ("resource", "describe"): _resource_describe,
    ("webapp",   "update"):   _webapp_update,
    ("webapp",   "show"):     _webapp_show,
    ("webapp",   "notify"):   _webapp_notify,
    ("webapp",   "restart"):  _webapp_restart,
}
