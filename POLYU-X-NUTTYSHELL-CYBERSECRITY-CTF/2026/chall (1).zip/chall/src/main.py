#1!/usr/bin/env python3
import os
import sys
import subprocess
import re
import tempfile 
import base64 

def die(msg):
    print(msg)
    sys.exit(0)

print("Welcome to Nutty Rust Jail! Can you escape and get the flag?")

code = input("Input your code here!:")

print(code)

if not code.strip():
    die("No input provided")
banned = [
    "unsafe",          # Blocks unsafe code (potential syscall bypass)
    "extern",          # Blocks FFI
    "std::fs",         # Blocks entire fs module (read, read_to_string, etc.)
    "std::process",    # Blocks Command/spawning processes
    "Command",         # Extra check for process spawning
    "include!",        # Blocks include macros
    "include_bytes!",  # Blocks binary file embedding
    "asm!",            # Blocks inline assembly
    "global_asm!",     # Blocks global assembly
    "proc_macro",      # Blocks custom macros
    "#![feature",      # Blocks unstable features
    "libc",            # Blocks raw C calls (e.g., open(2) syscall)
    "std::io",         # Blocks io module (Read trait, BufReader, etc.)
    "File::",          # Blocks File::open, etc. (partial to avoid banning "file" in comments)
    "read_to_string",  # Blocks fs::read_to_string and Read::read_to_string
    "read_to_end",     # Blocks Read::read_to_end
    "BufReader",       # Blocks buffered reading
    "BufRead",         # Blocks BufRead trait
    "std::path",       # Blocks Path/PathBuf (path manipulation)
    "canonicalize",    # Blocks path normalization bypasses
    "std::env::",      # Blocks env vars (e.g., env::current_dir for paths)
    "tokio::",         # Blocks async I/O (if someone tries to hint at it)
    "async_std::",     # Blocks alternative async std
    "memmap",          # Blocks memory-mapped files (if crate somehow sneaks in)
    "include_str!",    # Blocks include_str! macro for embedding text files
    "std::os",         # Blocks OS-specific extensions (e.g., std::os::unix::fs)
    "std::ffi",        # Blocks FFI string conversions
    "std::ptr",        # Blocks raw pointer manipulation
    "OpenOptions",     # Blocks alternative file opening
    "macro_rules!",    # Blocks users from creating macros to obfuscate code
    "core::",          # Blocks bypassing std:: by using core::
    "std::io::Read",   # Explicitly block the Read trait
    "std::fs::read",   # Block the exact function we just used
    "env!",            # Blocks compile-time env variable reading
    "option_env!",     # Blocks optional compile-time env reading
    "concat!",         # Blocks string concatenation macros to build banned words
    "stringify!",      # Blocks converting tokens to strings
    "from_raw",        # Blocks raw pointer to owned type conversions
    "transmute",       # Blocks type transmutation
    "as_ptr",          # Blocks pointer casting
    "from_ptr",        # Blocks constructing from raw pointers
    "dlopen",          # Blocks dynamic library loading
    "dlsym",           # Blocks dynamic symbol resolution
    "syscall",         # Blocks direct syscalls
    "nix::",           # Blocks nix crate (Unix API wrapper)
    "std::net",        # Blocks network access (exfiltration)
    "TcpStream",       # Blocks TCP connections
    "UdpSocket",       # Blocks UDP sockets
    "fs::",            # Blocks any fs:: usage even after tree imports
]

# Create a sanitized version of the code for checking
sanitized_code = code
# Remove single-line comments
sanitized_code = re.sub(r'//.*', '', sanitized_code)
# Remove multi-line comments
sanitized_code = re.sub(r'/\*.*?\*/', '', sanitized_code, flags=re.DOTALL)
# Remove all whitespace
sanitized_code = re.sub(r'\s+', '', sanitized_code)
# Remove curly braces to defeat tree-style import bypasses (e.g., use std::{fs})
sanitized_code = re.sub(r'[{}]', '', sanitized_code)

for b in banned:
    sanitized_b = re.sub(r'[\s{}]', '', b)
    if sanitized_b in sanitized_code:
        die(f"Banned word detected!: {b}")

# Check all banned words in base64 encoded form
encoded_banned = [re.escape(base64.b64encode(b.encode()).decode()) for b in banned]
for enc in encoded_banned:
    if re.search(enc, code):
        die("Banned encoded word detected!")

# Pattern checks
stripped = re.sub(r'\s+', '', code)
stripped = re.sub(r'[{}]', '', stripped)
if re.search(r'use.*fs', stripped, re.IGNORECASE):
    die("Suspicious import pattern detected!")
if re.search(r'use.*::\s*io', code, re.IGNORECASE):
    die("Suspicious import pattern detected!")
if re.search(r'use.*process', stripped, re.IGNORECASE):
    die("Suspicious import pattern detected!")

if "fn main()" not in code:
    die("Your program must define fn main()!")

if len(code) > 32:  # Tight limit to prevent abuse
    die("Code too long!")

env = os.environ.copy()
env["TMPDIR"] = "/tmp"
with tempfile.TemporaryDirectory(dir="/tmp") as tmp:
    rs = os.path.join(tmp, "main.rs")
    binf = os.path.join(tmp, "main")
    with open(rs, "w") as f:
        f.write(code)
    # Compile
    res = subprocess.run(
        ["rustc", rs, "-O", "-o", binf],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
        timeout=10
    )
    if res.returncode != 0:
        die("Compile error:\n" + res.stderr.decode())
    os.chmod(binf, 0o755)
    # Run
    try:
        subprocess.run(
            [binf],
            env=env,
            timeout=2
        )
    except subprocess.TimeoutExpired:
        die("Execution timed out")
    try:
        os.remove(rs)
        os.remove(binf)
    except OSError as e:
        print(f"Warning: Cleanup failed - {e}", file=sys.stderr)  # Non-fatal, but log it

    print("Program executed successfully. Did you get the flag?")
