<?php
header("Content-Security-Policy: default-src 'none'; script-src 'unsafe-inline'; frame-src 'none'; object-src 'none'; base-uri 'none';");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: DENY");

$redirectUri = $_GET['redirectUri'];
if (!isset($redirectUri) || empty($redirectUri)) {
    die('Missing redirect_uri parameter');
}
if (gettype($redirectUri) !== 'string') {
    die('redirect_uri parameter must be a string');
}
if (!filter_var($redirectUri, FILTER_VALIDATE_URL)) {
    die('redirect_uri parameter must be a valid URL');
}
if ($redirectUri !== 'http://example.com/') {
    die('redirect_uri parameter must be http://example.com/');
}

echo '<script>location = new URLSearchParams(window.location.search).get("redirectUri");</script>';