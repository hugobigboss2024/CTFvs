#!/bin/bash
set -e

php -S 127.0.0.1:9000 -t /var/www/html 2>&1 &
nginx -g 'daemon off;'