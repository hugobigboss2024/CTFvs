#!/usr/bin/env bash
set -Eeuo pipefail

if [ -z "${FLAG:-}" ]; then
  echo "FLAG env is required"
  exit 1
fi

wordpress_web_root_path="/var/www/html"
flag_suffix="$(head -c 32 /dev/urandom | md5sum | cut -d' ' -f1)"
flag_path="${wordpress_web_root_path}/flag_${flag_suffix}.txt"

# Clean up old flags
find "${wordpress_web_root_path}" -type f -name "flag_*.txt" -delete

echo "${FLAG}" > "${flag_path}"

unset FLAG

# If no command args were supplied, default to starting Apache
if [ "$#" -eq 0 ]; then
  set -- apache2-foreground
fi

exec /usr/local/bin/docker-entrypoint.sh "$@"