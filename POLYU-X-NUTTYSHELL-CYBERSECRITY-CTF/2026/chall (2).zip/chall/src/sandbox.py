#!/usr/bin/python3 -u
from RestrictedPython import compile_restricted_exec
from RestrictedPython.transformer import RestrictingNodeTransformer
from RestrictedPython.Guards import guarded_iter_unpack_sequence, safe_globals
from RestrictedPython.PrintCollector import PrintCollector
import json.encoder
import ast

class CustomRestrictingTransformer(RestrictingNodeTransformer):
    """Custom transformer that allows __getitem__/__setitem__ but blocks other dunders."""
    
    def check_name(self, node, name, *args, **kwargs):
        """Override to allow subscript dunders but block dangerous ones."""
        ALLOWED_DUNDERS = {'__getitem__', '__setitem__'}
        BANNED_ATTRS = {
            '__subclasses__', '__bases__', '__mro__', '__class__',
            '__globals__', '__builtins__', '__import__',
            '__loader__', '__spec__', '__qualname__',
            '__code__', '__func__', '__self__', '__wrapped__',
            '__dict__', '__dir__',
            '__getattribute__', '__getattr__',
            '__reduce__', '__reduce_ex__',
            'gi_frame', 'gi_code', 'cr_frame', 'cr_code',
            'ag_frame', 'ag_code',
            'f_locals', 'f_globals', 'f_builtins', 'f_back', 'f_code',
            'co_consts', 'co_names', 'co_code', 'co_varnames',
        }
        
        if name in BANNED_ATTRS:
            self.error(node, f'"{name}" is a blocked attribute')
            return
        
        if name in ALLOWED_DUNDERS:
            return
        
        return super().check_name(node, name, *args, **kwargs)

def guarded_getattr(obj, name, default=None):
    """Custom guard that blocks dangerous attributes."""
    BANNED = {
        '__subclasses__', '__bases__', '__mro__', '__class__',
        '__globals__', '__builtins__', '__import__',
        '__loader__', '__spec__', '__qualname__',
        '__code__', '__func__', '__self__', '__wrapped__',
        '__dict__', '__dir__',
        '__getattribute__', '__getattr__',
        '__reduce__', '__reduce_ex__',
        'gi_frame', 'gi_code', 'cr_frame', 'cr_code',
        'ag_frame', 'ag_code',
        'f_locals', 'f_globals', 'f_builtins', 'f_back', 'f_code',
        'co_consts', 'co_names', 'co_code', 'co_varnames',
    }
    
    if name in BANNED:
        raise AttributeError(f"access to '{name}' is blocked")
    
    return getattr(obj, name, default)

def main():
    def safe_getitem(obj, index):
        """Safe subscript getter."""
        return obj[index]
    
    def safe_write(obj):
        """Guard for write operations - returns object unchanged."""
        return obj
    
    def inplacevar(op, x, y):
        """Handle augmented assignments (+=, -=, etc.)."""
        import operator
        ops = {
            '+=': operator.add,
            '-=': operator.sub,
            '*=': operator.mul,
            '/=': operator.truediv,
            '//=': operator.floordiv,
            '%=': operator.mod,
            '**=': operator.pow,
            '<<=': operator.lshift,
            '>>=': operator.rshift,
            '&=': operator.and_,
            '|=': operator.or_,
            '^=': operator.xor,
        }
        if op in ops:
            return ops[op](x, y)
        raise TypeError(f"Unsupported inplace operation: {op}")
    
    restricted_globals = safe_globals.copy()
    restricted_globals.update({
        '__builtins__': {
            'id': id,
            'int': int,
            'bytes': bytes,
            'bytearray': bytearray,
            'type': type,
            'range': range,
            'len': len,
            'ord': ord,
            'dict': dict,
            'isinstance': isinstance,
            '__build_class__': __build_class__,
            '_getattr_': guarded_getattr,
            '_getitem_': safe_getitem,
            '_write_': safe_write,
            '_getiter_': iter,
            '_iter_unpack_sequence_': guarded_iter_unpack_sequence,
            '_print_': PrintCollector,
            '_inplacevar_': inplacevar,
        },
        '__name__': '__main__',
        '__metaclass__': type,
        'c_make_encoder': json.encoder.c_make_encoder,
        '_print_': PrintCollector,
        '_getattr_': guarded_getattr,
        '_getitem_': safe_getitem,
        '_write_': safe_write,
        '_inplacevar_': inplacevar,
    })

    print("Art of CPython")
    print("Show me the art of breaking CPython.")
    print("End your code with: # EOF")

    code = ""
    try:
        while (line := input()) != "# EOF":
            code += line + "\n"
    except EOFError:
        pass

    if not code.strip():
        return

    try:
        result = compile_restricted_exec(
            code, 
            filename='<sandbox>',
            policy=CustomRestrictingTransformer
        )
        
        if result.errors:
            print(f"Compilation errors: {result.errors}")
            return
        
        exec(result.code, restricted_globals)
        
        if '_print' in restricted_globals:
            output = restricted_globals['_print']()
            if output:
                print(output, end='')
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"Error: {e}")


if __name__ == '__main__':
    main()
