from datetime import timedelta

class Settings:
    SECRET_KEY: str = "secretkey"
    ALGORITHM: str = "HS256"
    access_token_expire_delta: timedelta = timedelta(minutes=30)
    
    ADMIN_USERNAME: str = "admin"
    ADMIN_PASSWORD: str = "[REDACTED]"
    
    GUEST_USERNAME: str = "guest"
    GUEST_PASSWORD: str = "guestpass"
    
    NETTOOLS_LOG: str = "nettools.log"
    ALLOWED_COMMANDS = [] 

settings = Settings()