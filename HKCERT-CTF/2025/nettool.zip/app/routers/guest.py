from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app.core.security import get_current_guest_or_admin_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/guest/dashboard", response_class=HTMLResponse)
async def guest_dashboard(
    request: Request, 
    user: str = Depends(get_current_guest_or_admin_user)
):
    return templates.TemplateResponse("guest/dashboard.html", {
        "request": request,
        "user": user,
        "message": f"欢迎您，{user}！您已成功登录。"
    })