from fastapi import APIRouter, Request, status, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

from app.core.config import settings
from app.core.security import create_access_token

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "user": None, "error": None})

@router.post("/login", response_class=HTMLResponse)
async def login(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
):
    
    is_admin = (username == settings.ADMIN_USERNAME and password == settings.ADMIN_PASSWORD)
    is_guest = (username == settings.GUEST_USERNAME and password == settings.GUEST_PASSWORD)
    
    if is_admin:
        target_url = "/admin/nettools"
    elif is_guest:
        target_url = "/guest/dashboard"
    else:
        return templates.TemplateResponse(
            "login.html",
            {"request": request, "error": "用户名或密码错误", "user": None},
            status_code=status.HTTP_401_UNAUTHORIZED,
        )

    token = create_access_token({"sub": username})
    
    response = RedirectResponse(url=target_url, status_code=status.HTTP_302_FOUND)
    response.set_cookie(key="access_token", value=f"Bearer {token}", httponly=True, samesite="strict")
    return response

@router.get("/logout")
async def logout():
    response = RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    response.delete_cookie(key="access_token")
    return response