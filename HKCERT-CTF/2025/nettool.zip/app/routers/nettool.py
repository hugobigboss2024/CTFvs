import socket
import json
import httpx
import traceback
from datetime import datetime
from typing import Optional, Dict, Any

from fastapi import APIRouter, Request, Depends, Form, HTTPException, status
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app.core.config import settings
from app.core.security import get_current_admin_user

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

def log_nettools_entry(entry: str, user: str) -> None:
    ts = datetime.utcnow().isoformat()
    line = f"[{ts}][USER: {user}] {entry}\n"
    with open(settings.NETTOOLS_LOG, "a", encoding="utf-8") as f:
        f.write(line)

@router.get("/admin/nettools", response_class=HTMLResponse)
async def nettools_page(request: Request, user: str = Depends(get_current_admin_user)):
    history_lines = []
    try:
        with open(settings.NETTOOLS_LOG, "r", encoding="utf-8") as f:
            history_lines = f.readlines()[-50:]
    except FileNotFoundError:
        history_lines = ["暂无历史记录"]
        
    return templates.TemplateResponse("admin/nettools.html", {
        "request": request,
        "user": user,
        "result": None,
        "error": None,
        "form": {},
        "history": reversed(history_lines),
    })

@router.post("/admin/nettools", response_class=HTMLResponse)
async def nettools_action(
    request: Request,
    user: str = Depends(get_current_admin_user),
    http_method: str = Form("GET"),
    http_url: str = Form(""),
    http_headers: str = Form(""),
    http_body: str = Form(""),
):
    result = ""
    error = None

    history_lines = []
    try:
        with open(settings.NETTOOLS_LOG, "r", encoding="utf-8") as f:
            history_lines = f.readlines()[-50:]
    except FileNotFoundError:
        pass

    try:
        if not http_url:
            raise ValueError("HTTP URL 不能为空")
        
        headers_dict: Dict[str, str] = {}
        if http_headers:
            try:
                headers_dict = json.loads(http_headers)
            except json.JSONDecodeError:
                raise ValueError("HTTP Headers 必须是有效的 JSON 格式")
        
        async with httpx.AsyncClient(timeout=10, verify=False) as client:
             r = await client.request(
                http_method.upper(), 
                http_url, 
                headers=headers_dict, 
                content=http_body.encode("utf-8") if http_method.upper() not in ["GET", "HEAD"] else None
            )

        formatted_headers = "\n".join([f"{k}: {v}" for k, v in r.headers.items()])
        result = f"Status: {r.status_code}\n\nHeaders:\n{formatted_headers}\n\nBody:\n{r.text[:4000]}"
        log_nettools_entry(f"HTTP {http_method} {http_url} -> {r.status_code}", user)
            
    except Exception as e:
        error = str(e)
        log_nettools_entry(f"ERROR: {error}", user)

    form_data = {
        "http_method": http_method,
        "http_url": http_url,
        "http_headers": http_headers,
        "http_body": http_body,
    }

    return templates.TemplateResponse("admin/nettools.html", {
        "request": request,
        "user": user,
        "result": result,
        "error": error,
        "form": form_data,
        "history": reversed(history_lines),
    })