from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.templating import Jinja2Templates

from app.routers import auth, nettool, guest

app = FastAPI()

app.include_router(auth.router, tags=["Authentication"])
app.include_router(nettool.router, tags=["Admin Tools"])
app.include_router(guest.router, tags=["Guest Pages"])

@app.get("/")
async def root():
    return RedirectResponse(url="/login")